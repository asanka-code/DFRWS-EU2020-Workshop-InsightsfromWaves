This is a simple module for EMvidence for demonstration purposes. The module is capable of classifying between two different signal classes.
